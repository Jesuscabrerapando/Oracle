CREATE TYPE TipoCliente AS OBJECT (
    CIF VARCHAR2(10),
    Nombre VARCHAR2(100),
    Direccion VARCHAR2(200),
    Telefono VARCHAR2(20),
    Email VARCHAR2(100),
    NumeroCuenta VARCHAR2(20),
    MEMBER FUNCTION obtenerInfoCliente RETURN VARCHAR2
);

CREATE TABLE TablaCliente OF TipoCliente;
ALTER TABLE TablaCliente ADD PRIMARY KEY (CIF);
/

CREATE TYPE TipoPedido AS OBJECT (
    ID_Pedido NUMBER,
    CIF VARCHAR2(10),
    Fecha_Emision DATE,
    Fecha_Devolucion DATE,
    Fecha_Entrega DATE,
    Estado VARCHAR2(20),
    MEMBER FUNCTION obtenerInfoPedido RETURN VARCHAR2
);

CREATE TABLE TablaPedido OF TipoPedido;
ALTER TABLE TablaPedido ADD PRIMARY KEY (ID_Pedido);
ALTER TABLE TablaPedido ADD FOREIGN KEY (CIF) REFERENCES TablaCliente(CIF);

/

CREATE TYPE TipoProducto AS OBJECT (
    ID_Producto NUMBER,
    Nombre VARCHAR2(100),
    Categoria VARCHAR2(50),
    Descripcion VARCHAR2(200),
    Disponibilidad VARCHAR2(20),
    MEMBER FUNCTION obtenerInfoProducto RETURN VARCHAR2
);

CREATE TABLE TablaProducto OF TipoProducto;
ALTER TABLE TablaProducto ADD PRIMARY KEY (ID_Producto);
/

CREATE TYPE TipoTransporte AS OBJECT (
    Matricula VARCHAR2(20),
    Cantidad NUMBER,
    Modelo VARCHAR2(50),
    MEMBER FUNCTION obtenerInfoTransporte RETURN VARCHAR2
);

CREATE TABLE TablaTransporte OF TipoTransporte;
ALTER TABLE TablaTransporte ADD PRIMARY KEY (Matricula);
/

CREATE TYPE TipoFactura AS OBJECT (
    ID_Factura NUMBER,
    ID_Pedido NUMBER,
    Fecha_Factura DATE,
    Importe NUMBER,
    MEMBER FUNCTION obtenerInfoFactura RETURN VARCHAR2
);

CREATE TABLE TablaFactura OF TipoFactura;
ALTER TABLE TablaFactura ADD PRIMARY KEY (ID_Factura);
ALTER TABLE TablaFactura ADD FOREIGN KEY (ID_Pedido) REFERENCES TablaPedido(ID_Pedido);
/

CREATE TABLE TablaPedido_Producto (
    ID_Pedido NUMBER,
    ID_Producto NUMBER,
    Precio NUMBER,
    CONSTRAINT Pedido_Producto_PK PRIMARY KEY (ID_Pedido, ID_Producto),
    CONSTRAINT Pedido_Producto_Pedido_FK FOREIGN KEY (ID_Pedido) REFERENCES TablaPedido(ID_Pedido),
    CONSTRAINT Pedido_Producto_Producto_FK FOREIGN KEY (ID_Producto) REFERENCES TablaProducto(ID_Producto)
);

CREATE TABLE TablaOrden_Transporte (
    ID_Orden_Transporte NUMBER,
    ID_Pedido NUMBER,
    Matricula VARCHAR2(20),
    Orden_Recogida VARCHAR2(100),
    CONSTRAINT Orden_Transporte_PK PRIMARY KEY (ID_Orden_Transporte),
    CONSTRAINT Orden_Transporte_Pedido_FK FOREIGN KEY (ID_Pedido) REFERENCES TablaPedido(ID_Pedido),
    CONSTRAINT Orden_Transporte_Transporte_FK FOREIGN KEY (Matricula) REFERENCES TablaTransporte(Matricula)
);


-- Insertar datos de prueba en TablaCliente
INSERT INTO TablaCliente (CIF, Nombre, Direccion, Telefono, Email, NumeroCuenta) VALUES ('CIF1', 'Cliente 1', 'Direcci�n 1', '123456789', 'cliente1@example.com', '1234567890');
INSERT INTO TablaCliente (CIF, Nombre, Direccion, Telefono, Email, NumeroCuenta) VALUES ('CIF2', 'Cliente 2', 'Direcci�n 2', '987654321', 'cliente2@example.com', '0987654321');

-- Insertar datos de prueba en TablaPedido
INSERT INTO TablaPedido (ID_Pedido, CIF, Fecha_Emision, Fecha_Devolucion, Fecha_Entrega, Estado) VALUES (1, 'CIF1', TO_DATE('2023-01-01', 'YYYY-MM-DD'), TO_DATE('2023-01-05', 'YYYY-MM-DD'), TO_DATE('2023-01-10', 'YYYY-MM-DD'), 'En proceso');
INSERT INTO TablaPedido (ID_Pedido, CIF, Fecha_Emision, Fecha_Devolucion, Fecha_Entrega, Estado) VALUES (2, 'CIF2', TO_DATE('2023-02-01', 'YYYY-MM-DD'), TO_DATE('2023-02-05', 'YYYY-MM-DD'), TO_DATE('2023-02-10', 'YYYY-MM-DD'), 'Completado');

-- Insertar datos de prueba en TablaProducto
INSERT INTO TablaProducto (ID_Producto, Nombre, Categoria, Descripcion, Disponibilidad) VALUES (1, 'Producto 1', 'Categor�a 1', 'Descripci�n 1', 'Disponible');
INSERT INTO TablaProducto (ID_Producto, Nombre, Categoria, Descripcion, Disponibilidad) VALUES (2, 'Producto 2', 'Categor�a 2', 'Descripci�n 2', 'No disponible');

-- Insertar datos de prueba en TablaTransporte
INSERT INTO TablaTransporte (Matricula, Cantidad, Modelo) VALUES ('ABC123', 1, 'Modelo 1');
INSERT INTO TablaTransporte (Matricula, Cantidad, Modelo) VALUES ('XYZ987', 2, 'Modelo 2');

-- Insertar datos de prueba en TablaFactura
INSERT INTO TablaFactura (ID_Factura, ID_Pedido, Fecha_Factura, Importe) VALUES (1, 1, TO_DATE('2023-01-15', 'YYYY-MM-DD'), 100.50);
INSERT INTO TablaFactura (ID_Factura, ID_Pedido, Fecha_Factura, Importe) VALUES (2, 2, TO_DATE('2023-02-15', 'YYYY-MM-DD'), 200.75);

-- Insertar datos de prueba en TablaPedido_Producto
INSERT INTO TablaPedido_Producto (ID_Pedido, ID_Producto, Precio) VALUES (1, 1, 50.25);
INSERT INTO TablaPedido_Producto (ID_Pedido, ID_Producto, Precio) VALUES (1, 2, 75.50);
INSERT INTO TablaPedido_Producto (ID_Pedido, ID_Producto, Precio) VALUES (2, 2, 100.25);

-- Insertar datos de prueba en TablaOrden_Transporte
INSERT INTO TablaOrden_Transporte (ID_Orden_Transporte, ID_Pedido, Matricula, Orden_Recogida) VALUES (1, 1, 'ABC123', 'Orden de recogida 1');
INSERT INTO TablaOrden_Transporte (ID_Orden_Transporte, ID_Pedido, Matricula, Orden_Recogida) VALUES (2, 2, 'XYZ987', 'Orden de recogida 2');


SELECT * FROM TablaPedido WHERE Estado = 'Completado';

SELECT * FROM TablaPedido;

SELECT * FROM TablaProducto;

SELECT * FROM TablaTransporte;

SELECT * FROM TablaFactura;

SELECT * FROM TablaPedido WHERE Estado = 'En proceso';

SELECT * FROM TablaProducto WHERE Disponibilidad = 'Disponible';

SELECT * FROM TablaProducto WHERE Disponibilidad = 'No disponible';

SELECT TP.* FROM TablaPedido TP
JOIN TablaFactura TF ON TP.ID_Pedido = TF.ID_Pedido;

SELECT TP.*, TT.* FROM TablaPedido TP
JOIN TablaOrden_Transporte TOT ON TP.ID_Pedido = TOT.ID_Pedido
JOIN TablaTransporte TT ON TOT.Matricula = TT.Matricula;


SELECT TP., TPP.Precio, TT. FROM TablaProducto TP
JOIN TablaPedido_Producto TPP ON TP.ID_Producto = TPP.ID_Producto
JOIN TablaPedido TPed ON TPed.ID_Pedido = TPP.ID_Pedido
JOIN TablaOrden_Transporte TOT ON TPed.ID_Pedido = TOT.ID_Pedido
JOIN TablaTransporte TT ON TOT.Matricula = TT.Matricula
WHERE TPed.ID_Pedido = 1;

SELECT TP.*, TPP.*, TPed.*, TT.* FROM TablaPedido TP
JOIN TablaPedido_Producto TPP ON TP.ID_Pedido = TPP.ID_Pedido
JOIN TablaProducto TPed ON TPP.ID_Producto = TPed.ID_Producto
JOIN TablaOrden_Transporte TOT ON TP.ID_Pedido = TOT.ID_Pedido
JOIN TablaTransporte TT ON TOT.Matricula = TT.Matricula;

SELECT TP.*, TF.Importe
FROM TablaProducto TP
JOIN TablaPedido_Producto TPP ON TP.ID_Producto = TPP.ID_Producto
JOIN TablaFactura TF ON TPP.ID_Pedido = TF.ID_Pedido
WHERE TF.Importe > 150;

SELECT TP.*
FROM TablaProducto TP
JOIN TablaPedido_Producto PP ON TP.ID_Producto = PP.ID_Producto
JOIN TablaPedido P ON PP.ID_Pedido = P.ID_Pedido
WHERE P.Estado <> 'Entregado';

SELECT Categoria, SUM(PP.Precio) AS TotalVentas
FROM TablaPedido_Producto PP
JOIN TablaProducto TP ON PP.ID_Producto = TP.ID_Producto
GROUP BY Categoria;

SELECT TT.Matricula, COUNT(TOT.ID_Pedido) AS TotalPedidos
FROM TablaTransporte TT
JOIN TablaOrden_Transporte TOT ON TT.Matricula = TOT.Matricula
GROUP BY TT.Matricula;

SELECT TT.Matricula, COUNT(TOT.ID_Pedido) AS TotalPedidos
FROM TablaTransporte TT
JOIN TablaOrden_Transporte TOT ON TT.Matricula = TOT.Matricula
GROUP BY TT.Matricula
ORDER BY TotalPedidos DESC;

SELECT TT.Matricula, COUNT(TP.ID_Pedido) AS TotalPedidosCompletados
FROM TablaTransporte TT
JOIN TablaOrden_Transporte TOT ON TT.Matricula = TOT.Matricula
JOIN TablaPedido TP ON TOT.ID_Pedido = TP.ID_Pedido
WHERE TP.Estado = 'Completado'
GROUP BY TT.Matricula;

SELECT TT.Matricula, COUNT(TP.ID_Pedido) AS TotalPedidosCompletados
FROM TablaTransporte TT
JOIN TablaOrden_Transporte TOT ON TT.Matricula = TOT.Matricula
JOIN TablaPedido TP ON TOT.ID_Pedido = TP.ID_Pedido
WHERE TP.Estado = 'Completado'
GROUP BY TT.Matricula
ORDER BY TotalPedidosCompletados DESC;

SELECT TT.Matricula, COUNT(TP.ID_Pedido) AS TotalPedidos
FROM TablaTransporte TT
JOIN TablaOrden_Transporte TOT ON TT.Matricula = TOT.Matricula
JOIN TablaPedido TP ON TOT.ID_Pedido = TP.ID_Pedido
GROUP BY TT.Matricula
ORDER BY TotalPedidos DESC;